from setuptools import setup

setup(
    name='practice_module',
    version='1.0.0',
    packages=['practice', 'practice.Test'],
    url='www.github.com',
    license='Free',
    author='simon',
    author_email='simonmatthew@naver.com',
    description='Practice Practice'
)
